# Market-project

1. Developed an online stock simulator where users get virtual money, through which a user can buy stocks and can sell stocks online virtually.  
2. Implemented MODELS, FORMS, VIEWS and linked them with Mongodb database file to store and view results in a classified manner.
3. Technologies used :- HTML5, CSS3, BootStrap4, MySQL, NodeJs., markitondemand API .
